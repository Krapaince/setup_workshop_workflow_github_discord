/*
** EPITECH PROJECT, 2020
** OOP_arcade_2019
** File description:
** core
*/

#define CATCH_CONFIG_MAIN
#include <catch2.hpp>
