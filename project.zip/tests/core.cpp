#include <catch2.hpp>
#include <catch2_redirect.hpp>

#include <core.hpp>

TEST_CASE("core", "[CORE]")
{
    streamRedirecter os{std::cout};

    CHECK(core() == 0);
    CHECK(os.str() == "Can you fix the bug\n");
}
