#include <core.hpp>

int main()
{
    return core();
}
