#include <iostream>
#include <string>

int core()
{
    std::cout << "Can you fix the bug\n";
    return 0;
}
