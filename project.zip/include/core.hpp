#ifndef CORE_HPP_
#define CORE_HPP_

int core();

#endif /* !CORE_HPP_ */

